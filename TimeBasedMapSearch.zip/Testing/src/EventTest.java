import java.time.ZonedDateTime;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class EventTest {
	public static void main(String[] args) throws InterruptedException {
		ExecutorService executorService = Executors.newFixedThreadPool(3);
		EventWindowSort eventWindowSort = new EventWindowSort();
		int numberOfThreads = 2;

		
		//Runnable producer = () -> IntStream
		//		.rangeClosed(0, 100)
		//		.forEach(index -> eventWindowSort.acceptEvent(
		//				new Event(ZonedDateTime.now().minusSeconds(index), UUID.randomUUID().toString()))
		//				);

		//for (int i = 0; i < numberOfThreads; i++) {
		//	executorService.execute(producer);
		//}
		
		//eventWindowSort.acceptEvent(new Event(ZonedDateTime.now(), UUID.randomUUID().toString()));
		
		
		// current time - 3 MINUTES (this event does not occur in the last minute).
		eventWindowSort.acceptEvent(new Event(ZonedDateTime.now().minusMinutes(3L), UUID.randomUUID().toString()));
		System.out.println(eventWindowSort.getEventsFromLastMinute());

		// current time - 30 seconds (this event does occur in the last minute).
		eventWindowSort.acceptEvent(new Event(ZonedDateTime.now().minusSeconds(30L), UUID.randomUUID().toString()));
		//System.out.println("This is waiting" + eventWindowSort.getEventsFromLastMinute());

		
		//ZonedDateTime time = ZonedDateTime.now().minusSeconds(35L);
		//eventWindowSort.acceptEvent(new Event(time, UUID.randomUUID().toString()));

		//Thread.sleep(1000);
		System.out.println(eventWindowSort.getEventsFromLastMinute());
		//eventWindowSort.acceptEvent(new Event(ZonedDateTime.now().minusSeconds(30L), UUID.randomUUID().toString()));
		//eventWindowSort.acceptEvent(new Event(time, UUID.randomUUID().toString()));
		//System.out.println(eventWindowSort.getEventsFromLastMinute());

	}
}
